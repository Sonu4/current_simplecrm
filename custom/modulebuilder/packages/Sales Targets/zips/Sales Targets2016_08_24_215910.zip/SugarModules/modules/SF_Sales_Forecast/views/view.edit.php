<?php

if (!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

class SF_Sales_ForecastViewEdit extends ViewEdit
{
 	public function __construct()
 	{
 		parent::ViewEdit();
 		$this->useForSubpanel = true;
 		$this->useModuleQuickCreateTemplate = true;
 		
 	}
 	function display()
 	{
		      $recordID = $this->bean->id;
		echo $javacript = <<<EOD
		<script>
		function checkStatus(){
				var assigned_user_id = $('#users_sf_sales_forecast_1users_ida').val();
				var year = $('#year').val();
				var quarter = $('#quarter').val();
				var id = '$recordID';
				if(id == '')
				{
				$.ajax({
							url:'CheckUser.php', // root file 
										type: 'GET',
										async: false,
										data:
										{
											assigned_user_id:assigned_user_id, 
											year:year,
											quarter:quarter,
										},
							success:function(result) {
							if(result > 0)
							{
								alert('You can\'t create more than one Sales Target record for the selected Sales User, Fiscal Year & Quarter');
								retTrue = 'False';
							}
							else
							{
								retTrue = 'True';
							}
					}
				});
				if(retTrue == 'True')
						{
							return true;
						}
						else if(retTrue == 'False')
						{
							return false;
						}
						else
						{
							return true;
						}
				}
			else
				{
					return true;
			}
		}
		$(document).ready(function(){
		$('#opportunities_won').attr('readonly',true);
		});
		</script>
EOD;
		parent::display();
	}
}
?>
