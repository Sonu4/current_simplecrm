<?php 
 // created: 2016-10-03 11:13:31
$mod_strings['LBL_TEAMS'] = 'Teams';
$mod_strings['LBL_ESCALATION_LEVEL'] = 'Escalation Level';
$mod_strings['LBL_ESCALATION_MINUTES_LEVEL2'] = 'Escalation Minutes';
$mod_strings['LBL_ESCALATION_MINUTES_LEVEL3'] = 'Escalation Minutes';
$mod_strings['LBL_ESCALATION_MINUTES_LEVEL1'] = 'Escalation Minutes';
$mod_strings['LBL_EMAIL_TEMPLATE_1'] = 'Email Template';
$mod_strings['LBL_EMAIL_TEMPLATE_3'] = 'Email Template';
$mod_strings['LBL_EMAIL_TEMPLATE_2'] = 'Email Template';
$mod_strings['LBL_EDITVIEW_PANEL1'] = 'Level3 Escalation';
$mod_strings['LBL_EDITVIEW_PANEL3'] = 'Level2 Escalation';
$mod_strings['LBL_EDITVIEW_PANEL5'] = 'Level1 Escalation';

?>
