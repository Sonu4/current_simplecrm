<?php
 // created: 2016-04-15 15:54:56
$dictionary['scrm_Escalation_Matrix']['fields']['escalation_minutes_level2_c']['inline_edit']='1';
$dictionary['scrm_Escalation_Matrix']['fields']['escalation_minutes_level2_c']['labelValue']='escalation minutes level2';

 ?>