<?php
 // created: 2016-04-15 15:59:40
$dictionary['scrm_Escalation_Matrix']['fields']['email_template_2_c']['inline_edit']='1';
$dictionary['scrm_Escalation_Matrix']['fields']['email_template_2_c']['labelValue']='email template 2';

 ?>