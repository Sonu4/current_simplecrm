<?php
 // created: 2016-04-15 15:55:38
$dictionary['scrm_Escalation_Matrix']['fields']['escalation_minutes_level3_c']['inline_edit']='1';
$dictionary['scrm_Escalation_Matrix']['fields']['escalation_minutes_level3_c']['labelValue']='escalation minutes level3';

 ?>