<?php
 // created: 2016-04-15 17:57:19
$dictionary['scrm_Escalation_Matrix']['fields']['escalation_level_c']['inline_edit']='1';
$dictionary['scrm_Escalation_Matrix']['fields']['escalation_level_c']['labelValue']='Escalation Level';

 ?>