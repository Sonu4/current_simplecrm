<?php
 // created: 2016-04-15 12:25:58
$dictionary['scrm_Escalation_Matrix']['fields']['teams_c']['inline_edit']='1';
$dictionary['scrm_Escalation_Matrix']['fields']['teams_c']['labelValue']='Teams';

 ?>