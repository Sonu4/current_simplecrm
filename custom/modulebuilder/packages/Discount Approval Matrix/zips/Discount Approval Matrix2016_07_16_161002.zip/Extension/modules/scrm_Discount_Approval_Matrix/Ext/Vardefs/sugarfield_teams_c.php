<?php
 // created: 2016-06-07 20:44:30
$dictionary['scrm_Discount_Approval_Matrix']['fields']['teams_c']['inline_edit']='1';
$dictionary['scrm_Discount_Approval_Matrix']['fields']['teams_c']['labelValue']='Teams';

 ?>