<?php
 // created: 2016-06-07 20:46:20
$dictionary['scrm_Discount_Approval_Matrix']['fields']['discount1_c']['inline_edit']='1';
$dictionary['scrm_Discount_Approval_Matrix']['fields']['discount1_c']['labelValue']='Discount1';

 ?>