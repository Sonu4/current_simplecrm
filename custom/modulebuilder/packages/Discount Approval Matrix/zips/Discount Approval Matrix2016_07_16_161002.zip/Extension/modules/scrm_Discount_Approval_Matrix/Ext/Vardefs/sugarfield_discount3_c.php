<?php
 // created: 2016-06-07 20:46:58
$dictionary['scrm_Discount_Approval_Matrix']['fields']['discount3_c']['inline_edit']='1';
$dictionary['scrm_Discount_Approval_Matrix']['fields']['discount3_c']['labelValue']='Discount3';

 ?>