<?php
 // created: 2016-06-07 20:45:32
$dictionary['scrm_Discount_Approval_Matrix']['fields']['role1_c']['inline_edit']='1';
$dictionary['scrm_Discount_Approval_Matrix']['fields']['role1_c']['labelValue']='Role1';

 ?>