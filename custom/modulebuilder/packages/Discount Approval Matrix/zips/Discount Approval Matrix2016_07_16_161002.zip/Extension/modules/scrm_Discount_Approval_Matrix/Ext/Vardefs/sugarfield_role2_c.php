<?php
 // created: 2016-06-07 20:45:09
$dictionary['scrm_Discount_Approval_Matrix']['fields']['role2_c']['inline_edit']='1';
$dictionary['scrm_Discount_Approval_Matrix']['fields']['role2_c']['labelValue']='Role';

 ?>