<?php
 // created: 2016-06-07 20:45:58
$dictionary['scrm_Discount_Approval_Matrix']['fields']['approval_levels_c']['inline_edit']='1';
$dictionary['scrm_Discount_Approval_Matrix']['fields']['approval_levels_c']['labelValue']='Approval Levels';

 ?>