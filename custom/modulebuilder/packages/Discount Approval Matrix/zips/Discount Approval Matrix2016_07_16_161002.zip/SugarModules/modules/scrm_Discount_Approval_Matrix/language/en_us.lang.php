<?php 
 // created: 2016-07-16 16:10:02
$mod_strings['LBL_TEAMS'] = 'Teams';
$mod_strings['LBL_ROLE3'] = 'Role3';
$mod_strings['LBL_ROLE2'] = 'Role';
$mod_strings['LBL_ROLE1'] = 'Role1';
$mod_strings['LBL_APPROVAL_LEVELS'] = 'Approval Levels';
$mod_strings['LBL_DISCOUNT1'] = 'Discount1';
$mod_strings['LBL_DISCOUNT2'] = 'Discount2';
$mod_strings['LBL_DISCOUNT3'] = 'Discount3';
$mod_strings['LBL_EDITVIEW_PANEL1'] = 'Level1';
$mod_strings['LBL_EDITVIEW_PANEL2'] = 'Level2';
$mod_strings['LBL_EDITVIEW_PANEL3'] = 'Level3';

?>
