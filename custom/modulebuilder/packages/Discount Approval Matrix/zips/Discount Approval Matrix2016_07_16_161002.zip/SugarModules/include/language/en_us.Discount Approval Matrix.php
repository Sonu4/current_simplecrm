<?php 
$app_list_strings['teams_list'] = array (
  '' => '',
  '38fc0012-fa73-1cb9-d1a8-55d721ee4f0a' => 'Sales Group',
  'bd98261b-7dd3-4709-7f29-55d7213bbd16' => 'Support Group',
);$app_list_strings['role1_0'] = array (
  '' => '',
  'Marketing Manager' => 'Marketing Manager',
  'Support Rep' => 'Support Rep',
  'Support Manager' => 'Support Manager',
  'Sales Manager' => 'Sales Manager',
  'Sales Rep' => 'Sales Rep',
);