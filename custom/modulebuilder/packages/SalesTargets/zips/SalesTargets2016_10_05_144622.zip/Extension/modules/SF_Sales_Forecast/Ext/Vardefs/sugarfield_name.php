<?php
 // created: 2016-05-10 11:54:25
$dictionary['SF_Sales_Forecast']['fields']['name']['full_text_search']=array (
);

 ?>