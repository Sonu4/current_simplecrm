<?php 
 // created: 2016-10-05 14:46:21
$mod_strings['LBL_SALES_TARGET'] = 'Sales Target($)';
$mod_strings['LBL_OPPORTUNITIES_WON'] = 'Opportunities Won($)';
$mod_strings['LBL_EDITVIEW_PANEL1'] = 'Other';
$mod_strings['LBL_NAME'] = 'Name';
$mod_strings['LBL_USERS_SF_SALES_FORECAST_1_FROM_USERS_TITLE'] = 'Sales User Name';

?>
