<?php 
 // created: 2016-08-06 17:11:51
$mod_strings['LBL_FEEDBACK_RESOLUTION_TIME'] = 'Was your issue resolved the first time you reported it?';
$mod_strings['LBL_FEEDBACK_EXPLAINATION_TIME'] = 'Was the engineer able to clearly articulate the troubleshooting steps on the call?';
$mod_strings['LBL_FEEDBACK_RESOLUTION_RESULT'] = 'Were you able to understand the tech support engineer clearly?';
$mod_strings['LBL_FEEDBACK_RECOMMENDATION_TIME'] = 'Will you recommend our service to your contacts?';
$mod_strings['LBL_FEEDBACK_RECOMMEND_FRIEND'] = 'Overall service rating';
$mod_strings['LBL_FEEBACK_SERVICE_RATING'] = 'How would you rate your overall satisfaction with SimpleCRM Support?';
$mod_strings['LBL_FEEDBACK_ON_WEBSITE'] = 'Will you allow us to use these remarks as testimonial on our website and in print?';
$mod_strings['LBL_FEEBACK_CASE_ID'] = 'feeback case id';
$mod_strings['LBL_FEEDBACK_DATE_ENTERED'] = 'Date Entered';
$mod_strings['LBL_FEEDBACK_DESCRIPTION'] = 'Remarks/Comments';

?>
