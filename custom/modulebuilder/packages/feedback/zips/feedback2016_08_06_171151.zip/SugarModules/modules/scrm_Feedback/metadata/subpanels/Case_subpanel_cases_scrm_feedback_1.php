<?php
// created: 2016-05-12 18:47:16
$subpanel_layout['list_fields'] = array (
  'feeback_service_rating_c' => 
  array (
    'type' => 'varchar',
    'default' => true,
    'vname' => 'LBL_FEEBACK_SERVICE_RATING',
    'width' => '10%',
  ),
  'feedback_resolution_time_c' => 
  array (
    'type' => 'varchar',
    'default' => true,
    'vname' => 'LBL_FEEDBACK_RESOLUTION_TIME',
    'width' => '10%',
  ),
  'feedback_explaination_time_c' => 
  array (
    'type' => 'varchar',
    'default' => true,
    'vname' => 'LBL_FEEDBACK_EXPLAINATION_TIME',
    'width' => '10%',
  ),
  'feedback_recommendation_time_c' => 
  array (
    'type' => 'varchar',
    'default' => true,
    'vname' => 'LBL_FEEDBACK_RECOMMENDATION_TIME',
    'width' => '10%',
  ),
  'feedback_resolution_result_c' => 
  array (
    'type' => 'varchar',
    'default' => true,
    'vname' => 'LBL_FEEDBACK_RESOLUTION_RESULT',
    'width' => '10%',
  ),
  'feedback_recommend_friend_c' => 
  array (
    'type' => 'varchar',
    'default' => true,
    'vname' => 'LBL_FEEDBACK_RECOMMEND_FRIEND',
    'width' => '10%',
  ),
  'edit_button' => 
  array (
    'vname' => 'LBL_EDIT_BUTTON',
    'widget_class' => 'SubPanelEditButton',
    'module' => 'scrm_Feedback',
    'width' => '5%',
    'default' => true,
  ),
  'remove_button' => 
  array (
    'vname' => 'LBL_REMOVE',
    'widget_class' => 'SubPanelRemoveButton',
    'module' => 'scrm_Feedback',
    'width' => '5%',
    'default' => true,
  ),
);