<?php
 // created: 2016-04-05 11:40:08
$dictionary['scrm_Feedback']['fields']['feedback_resolution_result_c']['inline_edit']='';
$dictionary['scrm_Feedback']['fields']['feedback_resolution_result_c']['labelValue']='Were you able to understand the tech support engineer clearly?';

 ?>