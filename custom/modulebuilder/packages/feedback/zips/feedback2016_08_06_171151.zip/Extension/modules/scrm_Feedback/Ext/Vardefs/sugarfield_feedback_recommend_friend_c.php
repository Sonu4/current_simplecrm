<?php
 // created: 2016-04-05 11:49:27
$dictionary['scrm_Feedback']['fields']['feedback_recommend_friend_c']['inline_edit']='';
$dictionary['scrm_Feedback']['fields']['feedback_recommend_friend_c']['labelValue']='Overall service rating';

 ?>