<?php
 // created: 2016-04-05 11:45:53
$dictionary['scrm_Feedback']['fields']['feedback_date_entered_c']['inline_edit']='';
$dictionary['scrm_Feedback']['fields']['feedback_date_entered_c']['labelValue']='Date Entered';

 ?>