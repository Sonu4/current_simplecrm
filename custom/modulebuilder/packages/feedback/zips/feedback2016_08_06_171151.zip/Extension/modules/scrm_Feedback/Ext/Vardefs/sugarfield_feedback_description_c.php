<?php
 // created: 2016-04-05 11:46:40
$dictionary['scrm_Feedback']['fields']['feedback_description_c']['inline_edit']='';
$dictionary['scrm_Feedback']['fields']['feedback_description_c']['labelValue']='Remarks/Comments';

 ?>