<?php
 // created: 2016-04-05 11:38:47
$dictionary['scrm_Feedback']['fields']['feedback_resolution_time_c']['inline_edit']='';
$dictionary['scrm_Feedback']['fields']['feedback_resolution_time_c']['labelValue']='Was your issue resolved the first time you reported it?';

 ?>