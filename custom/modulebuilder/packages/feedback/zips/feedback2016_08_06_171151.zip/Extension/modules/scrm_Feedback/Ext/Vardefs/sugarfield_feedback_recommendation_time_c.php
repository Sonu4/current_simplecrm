<?php
 // created: 2016-04-05 11:40:49
$dictionary['scrm_Feedback']['fields']['feedback_recommendation_time_c']['inline_edit']='';
$dictionary['scrm_Feedback']['fields']['feedback_recommendation_time_c']['labelValue']='Will you recommend our service to your contacts?';

 ?>