<?php
 // created: 2016-04-05 11:45:11
$dictionary['scrm_Feedback']['fields']['feeback_case_id_c']['inline_edit']='';
$dictionary['scrm_Feedback']['fields']['feeback_case_id_c']['labelValue']='feeback case id';

 ?>