<?php
 // created: 2016-04-05 11:39:22
$dictionary['scrm_Feedback']['fields']['feedback_explaination_time_c']['inline_edit']='';
$dictionary['scrm_Feedback']['fields']['feedback_explaination_time_c']['labelValue']='Was the engineer able to clearly articulate the troubleshooting steps on the call?';

 ?>