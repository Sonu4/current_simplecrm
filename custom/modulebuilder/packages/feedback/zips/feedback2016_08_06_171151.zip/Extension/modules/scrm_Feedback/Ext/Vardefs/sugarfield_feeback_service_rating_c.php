<?php
 // created: 2016-04-05 11:42:18
$dictionary['scrm_Feedback']['fields']['feeback_service_rating_c']['inline_edit']='';
$dictionary['scrm_Feedback']['fields']['feeback_service_rating_c']['labelValue']='How would you rate your overall satisfaction with SimpleCRM Support?';

 ?>