<?php
 // created: 2016-04-05 11:42:55
$dictionary['scrm_Feedback']['fields']['feedback_on_website_c']['inline_edit']='';
$dictionary['scrm_Feedback']['fields']['feedback_on_website_c']['labelValue']='Will you allow us to use these remarks as testimonial on our website and in print?';

 ?>