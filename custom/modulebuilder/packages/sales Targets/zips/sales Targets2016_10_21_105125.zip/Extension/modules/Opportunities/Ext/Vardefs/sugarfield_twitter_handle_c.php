<?php
 // created: 2016-04-19 12:58:30
$dictionary['Opportunity']['fields']['twitter_handle_c']['inline_edit']='1';
$dictionary['Opportunity']['fields']['twitter_handle_c']['labelValue']='twitter handle';

 ?>