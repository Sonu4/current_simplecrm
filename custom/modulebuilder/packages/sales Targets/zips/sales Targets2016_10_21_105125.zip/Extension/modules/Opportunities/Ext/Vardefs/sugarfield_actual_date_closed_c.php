<?php
 // created: 2016-05-10 14:03:19
$dictionary['Opportunity']['fields']['actual_date_closed_c']['inline_edit']='1';
$dictionary['Opportunity']['fields']['actual_date_closed_c']['labelValue']='Actual Date Closed';

 ?>