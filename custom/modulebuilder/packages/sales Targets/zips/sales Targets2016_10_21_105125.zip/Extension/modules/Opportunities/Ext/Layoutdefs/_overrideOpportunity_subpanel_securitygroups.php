<?php
//auto-generated file DO NOT EDIT
$layout_defs['Opportunities']['subpanel_setup']['securitygroups']['override_subpanel_name'] = 'Opportunity_subpanel_securitygroups';
?>