<?php
 // created: 2016-05-11 11:35:53
$dictionary['Opportunity']['fields']['reason_for_lost_c']['inline_edit']='1';
$dictionary['Opportunity']['fields']['reason_for_lost_c']['labelValue']='Reason for Lost';

 ?>