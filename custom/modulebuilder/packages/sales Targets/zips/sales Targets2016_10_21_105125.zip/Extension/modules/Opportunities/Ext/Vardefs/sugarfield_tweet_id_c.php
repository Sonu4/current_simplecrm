<?php
 // created: 2016-04-19 12:57:57
$dictionary['Opportunity']['fields']['tweet_id_c']['inline_edit']='1';
$dictionary['Opportunity']['fields']['tweet_id_c']['labelValue']='tweet id';

 ?>