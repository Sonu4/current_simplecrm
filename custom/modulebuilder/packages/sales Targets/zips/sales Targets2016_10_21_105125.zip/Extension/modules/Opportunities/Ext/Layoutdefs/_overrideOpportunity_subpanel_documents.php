<?php
//auto-generated file DO NOT EDIT
$layout_defs['Opportunities']['subpanel_setup']['documents']['override_subpanel_name'] = 'Opportunity_subpanel_documents';
?>