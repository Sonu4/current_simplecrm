<?php
if (!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

class UpdateDescriptionOpportunity{

function updateDescriptionFunctionOpportunity($bean, $event, $arguments){

 global $db;
 $record_id = $bean->id;
 $query1 ="UPDATE  opportunities SET description = REPLACE(description, ', Tweeted by :', '\r\nTweeted by :') WHERE id = '$record_id' AND deleted=0";
 $db->query($query1);

 $query2 ="UPDATE  opportunities SET description = REPLACE(description, ', Tweeted on :', '\r\nTweeted on :') WHERE id = '$record_id' AND deleted=0";
 $db->query($query2);


 $query3 ="UPDATE  opportunities SET description = REPLACE(description, ', Link to tweet :', '\r\nLink to tweet :') WHERE id = '$record_id' AND deleted=0";
 $db->query($query3);

}

}



