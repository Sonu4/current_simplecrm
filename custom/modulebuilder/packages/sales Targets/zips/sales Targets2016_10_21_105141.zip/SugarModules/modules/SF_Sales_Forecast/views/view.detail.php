<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

require_once('include/MVC/View/views/view.detail.php');

class SF_Sales_ForecastViewDetail extends ViewDetail {


 	function SF_Sales_ForecastViewDetail(){
 		parent::ViewDetail();
 	}
 	function display(){
		echo $js = <<<EOD
		<script>
		$(document).ready(function(){
			$('#duplicate_button').hide();
			$('#merge_duplicate_button').hide();
		});
		</script>
EOD;
			parent::display();
		
		}
		
}



