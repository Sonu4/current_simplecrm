<?php
 // created: 2016-05-10 14:06:22
$dictionary['Opportunity']['fields']['date_lost_c']['inline_edit']='1';
$dictionary['Opportunity']['fields']['date_lost_c']['labelValue']='Date Lost';

 ?>