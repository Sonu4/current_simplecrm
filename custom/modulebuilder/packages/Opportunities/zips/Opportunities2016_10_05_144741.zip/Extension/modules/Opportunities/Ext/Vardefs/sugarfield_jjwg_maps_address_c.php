<?php
 // created: 2015-08-20 11:47:31
$dictionary['Opportunity']['fields']['jjwg_maps_address_c']['inline_edit']=1;

 ?>