<?php
//auto-generated file DO NOT EDIT
$layout_defs['Opportunities']['subpanel_setup']['opportunity_aos_quotes']['override_subpanel_name'] = 'Opportunity_subpanel_opportunity_aos_quotes';
?>