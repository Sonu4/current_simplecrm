<?php 
 // created: 2016-10-05 14:47:40
$mod_strings['TWITTER_USER_C'] = 'Twitter User';
$mod_strings['LBL_DOCUMENTS_SUBPANEL_TITLE'] = 'Documents';
$mod_strings['LBL_CONTACTS_SUBPANEL_TITLE'] = 'Contacts';
$mod_strings['LBL_PROJECTS_SUBPANEL_TITLE'] = 'Projects';
$mod_strings['AOS_Quotes'] = 'Quotes';
$mod_strings['AOS_Contracts'] = 'Contracts';
$mod_strings['LBL_SECURITYGROUPS_SUBPANEL_TITLE'] = 'Security Groups';
$mod_strings['LBL_LEADS_SUBPANEL_TITLE'] = 'Leads';
$mod_strings['LBL_LEADS'] = 'Leads';
$mod_strings['LBL_LEAD_SOURCE'] = 'Lead Source:';
$mod_strings['LBL_TWEET_ID'] = 'tweet id';
$mod_strings['LBL_TWITTER_HANDLE'] = 'twitter handle';
$mod_strings['LBL_ACTUAL_DATE_CLOSED'] = 'Actual Date Closed';
$mod_strings['LBL_DATE_LOST_C'] = 'Date Lost';
$mod_strings['LBL_REASON_FOR_LOST'] = 'Reason for Lost';
$mod_strings['LBL_ACCOUNT_NAME'] = 'Account Name:';
$mod_strings['LBL_ACCOUNTS'] = 'Accounts';
$mod_strings['LBL_ACCOUNT_ID'] = 'Account ID';
$mod_strings['LBL_LIST_ACCOUNT_NAME'] = 'Account Name';

?>
